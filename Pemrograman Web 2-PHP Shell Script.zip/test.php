<?php

  $nim = "20090124";
  $nama = "Syah Putra Indra Pratama";
  $kelas = "4B";
    echo "My Biodata <br>
    NIM   : $nim <br>
    Nama  : $nama <br>
    Kelas : $kelas <br>";

 print("Semoga setelah mengenal kita bisa menyayangi sebab ada pepatah mengatakan 
        - Tak kenal maka tak sayang -");
  
?>
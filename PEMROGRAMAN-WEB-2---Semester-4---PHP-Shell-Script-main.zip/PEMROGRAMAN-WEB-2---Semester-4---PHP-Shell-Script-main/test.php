<?php

  $nim = "20090028";
  $nama = "Rizki Bimo Wijaya";
  $kelas = "4B";
    echo "My Biodata <br>
    NIM   : $nim <br>
    Nama  : $nama <br>
    Kelas : $kelas <br>";

 print("Semoga setelah mengenal kita bisa menyayangi sebab ada pepatah mengatakan 
        - Tak kenal maka tak sayang -");
  
?>